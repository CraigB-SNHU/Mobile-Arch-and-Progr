package bonner.craig;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.EditText;

public class UserDataBase extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "user.db";
    private static final int VERSION = 2;

    EditText addDate, addWeight;

    public UserDataBase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static final class UserTable {
        private static final String TABLE = "Weight Chart";
        private static final String DATE_COL = "Date";
        private static final String LBS_COL = "Weight";
        private static final String WTL_COL = "Weight to Lose";
    }

    // Add data to the database
    public void addUserData() {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.DATE_COL, addDate.getText().toString());
        values.put(UserTable.LBS_COL, addWeight.getText().toString());
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
